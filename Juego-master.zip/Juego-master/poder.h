#pragma once
#include <iostream>
#include <string>
using namespace std;
class poder
{
private: int tipoPoderes;
	   //la bola cambia de color a los enemigos y los hace vulnerables

};


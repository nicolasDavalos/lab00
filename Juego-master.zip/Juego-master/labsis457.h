#pragma once
#include <iostream>
#include <string>
using namespace std;
class personaje
{
public:
	int posicx;
	int posicy;
	int velocidad;
	int numero_vidas;
	void moverse(int posicx, int posicy)
	  //pacman que avance de izquierda a derecha de arriba a abajo usando las coordenadas x, y

};


#pragma once
#include <iostream>
#include <string>
using namespace std;
class fruta
{
private: 
	int cherry;
	//el cherry aumenta puntos
};


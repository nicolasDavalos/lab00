#pragma once
#include <iostream>
#include <string>
using namespace std;
class laberinto
{
public: int ancho, alto;
	  int muros;

	  string nombrelaberinto;
	  //las ubicaciones de los laberintos y muros 
};

